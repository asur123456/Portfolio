import React, { useState } from 'react';
import { ExternalLink, Github, Car, Shield, Globe, ChevronRight } from 'lucide-react';

const Projects = () => {
  const [activeProject, setActiveProject] = useState(0);

  const projects = [
    {
      id: 1,
      title: "Bluetooth Controlled Car",
      category: "IoT & Embedded Systems",
      description: "Engineered a wireless vehicle control system using Bluetooth communication, enabling real-time directional navigation via mobile app or serial commands.",
      longDescription: "This project demonstrates advanced IoT integration in smart mobility solutions. The system uses Arduino as the main controller, HC-05 Bluetooth module for wireless communication, and L293D motor driver for precise motor control. The vehicle can be controlled remotely through a mobile application or serial commands, showcasing real-time communication and embedded systems programming.",
      technologies: ["Arduino", "HC-05 Bluetooth", "L293D Motor Driver", "C++", "Mobile App Integration"],
      features: [
        "Real-time directional control via Bluetooth",
        "Mobile app and serial command interface",
        "Wireless communication up to 10 meters",
        "Precise motor control and navigation"
      ],
      icon: Car,
      gradient: "from-blue-500 to-cyan-500",
      impact: "Demonstrated practical IoT implementation in automotive applications"
    },
    {
      id: 2,
      title: "Breath Analyzer (Alcohol Detector)",
      category: "IoT Safety Systems",
      description: "Developed an Arduino-based breath analyzer using MQ3 alcohol sensor for real-time BAC detection to enhance vehicle safety protocols.",
      longDescription: "A comprehensive safety system that integrates sensor-based detection with automated vehicle control. The system uses MQ3 alcohol sensor for accurate BAC measurement and implements automated safety protocols including ignition disable functionality. This project addresses real-world safety concerns and demonstrates the potential for IoT in reducing drunk driving incidents.",
      technologies: ["Arduino", "MQ3 Alcohol Sensor", "Driver Module", "C++", "Sensor Calibration"],
      features: [
        "Real-time Blood Alcohol Content detection",
        "Automated ignition disable system",
        "Sensor-driven vehicle control logic",
        "Emergency response integration",
        "Up to 40% improvement in road safety"
      ],
      icon: Shield,
      gradient: "from-red-500 to-pink-500",
      impact: "Potential to reduce drunk driving incidents by 40% through automated safety protocols"
    },
    {
      id: 3,
      title: "WordPress Quote Collection Platform",
      category: "Web Development",
      description: "Led development of a WordPress-based quote collection platform offering curated motivational content with responsive design.",
      longDescription: "A full-featured web platform built on WordPress, designed to provide users with daily inspiration through curated quotes. The platform features a responsive design, real-time content updates, and user interaction capabilities. While primarily a web development project, it demonstrates full-stack capabilities and user experience design.",
      technologies: ["WordPress", "HTML5", "CSS3", "JavaScript", "Responsive Design"],
      features: [
        "Curated motivational quote collection",
        "Responsive and user-friendly interface",
        "Real-time content updates",
        "Quote submission system",
        "Category-based organization"
      ],
      icon: Globe,
      gradient: "from-green-500 to-teal-500",
      impact: "Enhanced user engagement through intuitive design and daily inspirational content"
    }
  ];

  return (
    <section id="projects" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            Featured Projects
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Innovative IoT solutions and embedded systems that solve real-world problems
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Project Cards */}
          <div className="lg:col-span-1 space-y-4">
            {projects.map((project, index) => {
              const IconComponent = project.icon;
              return (
                <div
                  key={project.id}
                  className={`p-6 rounded-xl cursor-pointer transition-all duration-300 ${
                    activeProject === index
                      ? 'bg-white shadow-xl scale-105'
                      : 'bg-white/50 hover:bg-white hover:shadow-lg'
                  }`}
                  onClick={() => setActiveProject(index)}
                >
                  <div className="flex items-center space-x-4">
                    <div className={`p-3 rounded-lg bg-gradient-to-r ${project.gradient}`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-800 mb-1">{project.title}</h3>
                      <p className="text-sm text-gray-600">{project.category}</p>
                    </div>
                    <ChevronRight className={`w-5 h-5 text-gray-400 transition-transform ${
                      activeProject === index ? 'rotate-90' : ''
                    }`} />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Project Details */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-xl p-8">
              {(() => {
                const project = projects[activeProject];
                const IconComponent = project.icon;
                return (
                  <>
                    <div className="flex items-center space-x-4 mb-6">
                      <div className={`p-4 rounded-xl bg-gradient-to-r ${project.gradient}`}>
                        <IconComponent className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-bold text-gray-800">{project.title}</h3>
                        <p className="text-blue-600 font-medium">{project.category}</p>
                      </div>
                    </div>

                    <p className="text-gray-600 mb-6 leading-relaxed">
                      {project.longDescription}
                    </p>

                    <div className="grid md:grid-cols-2 gap-6 mb-6">
                      <div>
                        <h4 className="font-semibold text-gray-800 mb-3">Key Features</h4>
                        <ul className="space-y-2">
                          {project.features.map((feature, index) => (
                            <li key={index} className="flex items-start space-x-2">
                              <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                              <span className="text-gray-600 text-sm">{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div>
                        <h4 className="font-semibold text-gray-800 mb-3">Technologies Used</h4>
                        <div className="flex flex-wrap gap-2">
                          {project.technologies.map((tech, index) => (
                            <span
                              key={index}
                              className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm font-medium"
                            >
                              {tech}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-lg mb-6">
                      <h4 className="font-semibold text-gray-800 mb-2">Project Impact</h4>
                      <p className="text-gray-700 text-sm">{project.impact}</p>
                    </div>

                    <div className="flex space-x-4">
                      <button className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                        <ExternalLink className="w-4 h-4" />
                        <span>View Details</span>
                      </button>
                      <button className="flex items-center space-x-2 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                        <Github className="w-4 h-4" />
                        <span>Source Code</span>
                      </button>
                    </div>
                  </>
                );
              })()}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;