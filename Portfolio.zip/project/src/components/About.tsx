import React from 'react';
import { GraduationCap, Zap, Target, Code } from 'lucide-react';

const About = () => {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            About Me
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Passionate about creating intelligent IoT solutions that solve real-world problems
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="flex items-start space-x-4">
              <div className="p-3 bg-blue-100 rounded-lg">
                <GraduationCap className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Education</h3>
                <p className="text-gray-600">
                  Currently pursuing B.Tech in Computer Science at Sharda University, Greater Noida. 
                  Specializing in IoT, embedded systems, and smart device development.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="p-3 bg-green-100 rounded-lg">
                <Zap className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">IoT Expertise</h3>
                <p className="text-gray-600">
                  Experienced in developing Arduino-based systems, sensor integration, wireless communication, 
                  and creating smart solutions for automotive safety and home automation.
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="p-3 bg-purple-100 rounded-lg">
                <Target className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Mission</h3>
                <p className="text-gray-600">
                  To bridge the gap between physical and digital worlds through innovative IoT solutions 
                  that enhance safety, efficiency, and quality of life.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-8 rounded-2xl">
            <div className="flex items-center space-x-3 mb-6">
              <Code className="w-8 h-8 text-blue-600" />
              <h3 className="text-2xl font-bold text-gray-800">Technical Focus</h3>
            </div>
            
            <div className="space-y-4">
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h4 className="font-semibold text-gray-800 mb-2">Embedded Systems</h4>
                <p className="text-gray-600 text-sm">Arduino, microcontroller programming, sensor integration</p>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h4 className="font-semibold text-gray-800 mb-2">IoT Communication</h4>
                <p className="text-gray-600 text-sm">Bluetooth, wireless protocols, real-time data transmission</p>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h4 className="font-semibold text-gray-800 mb-2">Smart Safety Systems</h4>
                <p className="text-gray-600 text-sm">Automotive safety, breath analyzers, automated control systems</p>
              </div>
              
              <div className="bg-white p-4 rounded-lg shadow-sm">
                <h4 className="font-semibold text-gray-800 mb-2">Full-Stack Development</h4>
                <p className="text-gray-600 text-sm">Web applications, responsive design, user interfaces</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;