import React from 'react';
import { Cpu, Wifi, Shield, Code, Database, Cloud } from 'lucide-react';

const Skills = () => {
  const skillCategories = [
    {
      title: "IoT & Embedded Systems",
      icon: Cpu,
      color: "blue",
      skills: [
        { name: "Arduino Programming", level: 90 },
        { name: "Microcontroller Integration", level: 85 },
        { name: "Sensor Networks", level: 80 },
        { name: "Embedded C/C++", level: 85 }
      ]
    },
    {
      title: "Wireless Communication",
      icon: Wifi,
      color: "green",
      skills: [
        { name: "Bluetooth (HC-05)", level: 90 },
        { name: "WiFi Protocols", level: 75 },
        { name: "Serial Communication", level: 85 },
        { name: "Real-time Data Transfer", level: 80 }
      ]
    },
    {
      title: "Safety & Automation",
      icon: Shield,
      color: "red",
      skills: [
        { name: "Automotive Safety Systems", level: 85 },
        { name: "Sensor-based Control", level: 90 },
        { name: "Emergency Response Systems", level: 80 },
        { name: "Automated Safety Protocols", level: 85 }
      ]
    },
    {
      title: "Programming Languages",
      icon: Code,
      color: "purple",
      skills: [
        { name: "Java", level: 85 },
        { name: "C/C++", level: 80 },
        { name: "JavaScript", level: 75 },
        { name: "Python", level: 70 }
      ]
    },
    {
      title: "Web Development",
      icon: Database,
      color: "indigo",
      skills: [
        { name: "HTML/CSS", level: 85 },
        { name: "React.js", level: 80 },
        { name: "WordPress", level: 85 },
        { name: "Responsive Design", level: 80 }
      ]
    },
    {
      title: "Cloud & Architecture",
      icon: Cloud,
      color: "cyan",
      skills: [
        { name: "AWS Solutions", level: 75 },
        { name: "Cloud Architecture", level: 70 },
        { name: "System Design", level: 75 },
        { name: "Scalable Solutions", level: 70 }
      ]
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: { bg: 'bg-blue-100', text: 'text-blue-600', progress: 'bg-blue-600' },
      green: { bg: 'bg-green-100', text: 'text-green-600', progress: 'bg-green-600' },
      red: { bg: 'bg-red-100', text: 'text-red-600', progress: 'bg-red-600' },
      purple: { bg: 'bg-purple-100', text: 'text-purple-600', progress: 'bg-purple-600' },
      indigo: { bg: 'bg-indigo-100', text: 'text-indigo-600', progress: 'bg-indigo-600' },
      cyan: { bg: 'bg-cyan-100', text: 'text-cyan-600', progress: 'bg-cyan-600' }
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <section id="skills" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            Technical Skills
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Specialized expertise in IoT development, embedded systems, and smart device integration
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillCategories.map((category, index) => {
            const IconComponent = category.icon;
            const colorClasses = getColorClasses(category.color);
            
            return (
              <div key={index} className="bg-gray-50 rounded-2xl p-6 hover:shadow-lg transition-shadow duration-300">
                <div className="flex items-center space-x-3 mb-6">
                  <div className={`p-3 rounded-lg ${colorClasses.bg}`}>
                    <IconComponent className={`w-6 h-6 ${colorClasses.text}`} />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800">{category.title}</h3>
                </div>

                <div className="space-y-4">
                  {category.skills.map((skill, skillIndex) => (
                    <div key={skillIndex}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-gray-700 font-medium">{skill.name}</span>
                        <span className="text-gray-500 text-sm">{skill.level}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className={`h-2 rounded-full ${colorClasses.progress} transition-all duration-1000 ease-out`}
                          style={{ width: `${skill.level}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Hardware & Tools Section */}
        <div className="mt-16 bg-gradient-to-br from-gray-50 to-blue-50 rounded-2xl p-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-6 text-center">Hardware & Development Tools</h3>
          
          <div className="grid md:grid-cols-3 gap-6">
            <div className="text-center">
              <h4 className="font-semibold text-gray-800 mb-3">Microcontrollers</h4>
              <div className="flex flex-wrap justify-center gap-2">
                {['Arduino Uno', 'Arduino Nano', 'ESP32', 'NodeMCU'].map((item, index) => (
                  <span key={index} className="px-3 py-1 bg-white text-gray-700 rounded-full text-sm shadow-sm">
                    {item}
                  </span>
                ))}
              </div>
            </div>
            
            <div className="text-center">
              <h4 className="font-semibold text-gray-800 mb-3">Sensors & Modules</h4>
              <div className="flex flex-wrap justify-center gap-2">
                {['MQ3 Alcohol Sensor', 'HC-05 Bluetooth', 'L293D Motor Driver', 'Ultrasonic Sensors'].map((item, index) => (
                  <span key={index} className="px-3 py-1 bg-white text-gray-700 rounded-full text-sm shadow-sm">
                    {item}
                  </span>
                ))}
              </div>
            </div>
            
            <div className="text-center">
              <h4 className="font-semibold text-gray-800 mb-3">Development Tools</h4>
              <div className="flex flex-wrap justify-center gap-2">
                {['Arduino IDE', 'VS Code', 'Git', 'Fritzing'].map((item, index) => (
                  <span key={index} className="px-3 py-1 bg-white text-gray-700 rounded-full text-sm shadow-sm">
                    {item}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;