import React from 'react';
import { Award, ExternalLink, Calendar, CheckCircle } from 'lucide-react';

const Certifications = () => {
  const certifications = [
    {
      title: "AWS Solution Architecture Job Simulation",
      provider: "Amazon Web Services",
      description: "Gained hands-on experience with designing scalable and cost-effective cloud solutions, developing hosting architectures, and understanding foundational AWS services relevant to real-world infrastructure planning.",
      skills: ["Cloud Architecture", "AWS Services", "Scalable Solutions", "Infrastructure Planning"],
      icon: "🏗️",
      color: "orange"
    },
    {
      title: "Full-Stack Web Development",
      provider: "Udemy",
      description: "Completed comprehensive Full-Stack Web Development Course, mastering HTML, CSS, JavaScript, React.js, while developing and deploying multiple responsive, real-world web applications.",
      skills: ["HTML/CSS", "JavaScript", "React.js", "Responsive Design", "Web Deployment"],
      icon: "🌐",
      color: "blue"
    },
    {
      title: "Java Skill Certification",
      provider: "One Roadmap",
      description: "Demonstrated strong proficiency in core Java programming concepts, including object-oriented design, control structures, data types, exception handling, and standard API usage.",
      skills: ["Core Java", "OOP Design", "Exception Handling", "Data Structures", "API Usage"],
      icon: "☕",
      color: "red"
    },
    {
      title: "Oracle Academy Java Programming",
      provider: "Oracle Academy",
      description: "Covered comprehensive Java programming concepts including classes and objects, inheritance, loops, arrays, and exception handling with practical implementation experience.",
      skills: ["Java Programming", "Classes & Objects", "Inheritance", "Arrays", "Control Structures"],
      icon: "🎓",
      color: "purple"
    }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      orange: { bg: 'bg-orange-50', border: 'border-orange-200', text: 'text-orange-600', button: 'bg-orange-600 hover:bg-orange-700' },
      blue: { bg: 'bg-blue-50', border: 'border-blue-200', text: 'text-blue-600', button: 'bg-blue-600 hover:bg-blue-700' },
      red: { bg: 'bg-red-50', border: 'border-red-200', text: 'text-red-600', button: 'bg-red-600 hover:bg-red-700' },
      purple: { bg: 'bg-purple-50', border: 'border-purple-200', text: 'text-purple-600', button: 'bg-purple-600 hover:bg-purple-700' }
    };
    return colors[color as keyof typeof colors];
  };

  return (
    <section id="certifications" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            Certifications & Learning
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Continuous learning and professional development in cutting-edge technologies
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {certifications.map((cert, index) => {
            const colorClasses = getColorClasses(cert.color);
            
            return (
              <div key={index} className={`bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 border-l-4 ${colorClasses.border}`}>
                <div className="flex items-start space-x-4 mb-6">
                  <div className={`p-4 rounded-xl ${colorClasses.bg} text-3xl`}>
                    {cert.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-800 mb-2">{cert.title}</h3>
                    <p className={`font-medium ${colorClasses.text} mb-3`}>{cert.provider}</p>
                    <div className="flex items-center space-x-2 text-gray-500 text-sm">
                      <CheckCircle className="w-4 h-4 text-green-500" />
                      <span>Completed</span>
                    </div>
                  </div>
                </div>

                <p className="text-gray-600 mb-6 leading-relaxed">
                  {cert.description}
                </p>

                <div className="mb-6">
                  <h4 className="font-semibold text-gray-800 mb-3">Skills Acquired</h4>
                  <div className="flex flex-wrap gap-2">
                    {cert.skills.map((skill, skillIndex) => (
                      <span
                        key={skillIndex}
                        className={`px-3 py-1 ${colorClasses.bg} ${colorClasses.text} rounded-full text-sm font-medium`}
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                <button className={`flex items-center space-x-2 px-6 py-3 ${colorClasses.button} text-white rounded-lg transition-colors`}>
                  <Award className="w-4 h-4" />
                  <span>View Certificate</span>
                  <ExternalLink className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Learning Philosophy */}
        <div className="mt-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-8 text-white text-center">
          <h3 className="text-2xl font-bold mb-4">Continuous Learning Philosophy</h3>
          <p className="text-blue-100 max-w-3xl mx-auto leading-relaxed">
            Technology evolves rapidly, especially in IoT and embedded systems. I believe in staying current with the latest 
            developments, from cloud architectures to new sensor technologies, ensuring my solutions are always cutting-edge 
            and industry-relevant.
          </p>
          <div className="flex justify-center space-x-8 mt-8">
            <div className="text-center">
              <div className="text-3xl font-bold">4+</div>
              <div className="text-blue-200 text-sm">Certifications</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">3+</div>
              <div className="text-blue-200 text-sm">IoT Projects</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">2+</div>
              <div className="text-blue-200 text-sm">Years Learning</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Certifications;